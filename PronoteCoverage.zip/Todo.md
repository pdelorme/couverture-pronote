Todo
----

Version 1
---------
1. ~~selection du tab "pronote".~~
3. ~~affichage des stats dans l'extention.~~
5. ~~persister stats~~
8. ~~nouveau logo.~~
10. ~~publication extension~~
13. ~~désynchroniser popup et page de scrap ->~~
    - ~~le popup affiche les données les plus récentes~~
    - ~~le scrap envoi les données au plugin eu fur et à mesure même si le popup est fermé.~~
    - la page de scrap est bloquée jusqu'à la fin du scrap (sauf bouton stop).
2. goto page TDM auto
4. scrap plus rapide : dés que tdm dispo.
6. ne parser que les dates non faites.
7. corriger l'adresse de l'etablissement.
9. ajouter "disclaimer"
11. test en conditions réélles.
12. formulaire google de prise en compte des retours.



Version 2
---------
1. Envoi vers serveur
2. Page de stats serveur (par matiere, classes et établissement).
3. Cartographie (heatmap) des couverture (par matiere).
4. Lien vers Carto.
5. gérer les fratries et les accès élèves
6. Prise ne compte des retours V1.

