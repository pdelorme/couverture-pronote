Politique de confidentialité
============================
L'extention Pronote Coverage ne collecte aucune donnée de quelque type que ce soit sans votre consentement explicite.

Dans tous les cas aucune donnée personnelle, nominative ou permetant de vous identifier ne sera collecté.

Pronote Coverage s'autorise cependant à collecter les données d'emploi du temps (et uniquement celle ci) à des fins de statistiques ou de cartographie de la couverture des enseignements de l'empoi du temps.

