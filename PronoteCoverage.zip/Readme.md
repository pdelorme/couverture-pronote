Présentation
------------
Ce repos contient une extention Chrome dont le but est de calculer le taux de non-remplacement des cours de votre enfant au travers d'une analyse des données pronote.

Il à été réalisé dans le cadre du hackathon des écoles organisé par le Donut le weekend du 14-15-16 juin 2024.

Installation
------------
1. telechargez le projet sur votre ordi.
2. dans Chrome, allez à l'adresse suivante : chrome://extensions/
3. Activez le mode developpeur (en hau à droite)
4. Chargez l'extention non-empactée (selectionnez le dossier téléchargé en 1.)
5. Allez sur pronot et authentifiez vous.
6. Sans changer d'écran, allez sur l'extension "Couverture Pronote", un popup s'affiche.
7. Appuyez sur le bouton "Rafraichir les statistiques"
8. Attendez un moment,
  - vous devriez voir la table des matieres changer toute seule de jour.
  - après un moment un tableau de résultats s'affiche.
